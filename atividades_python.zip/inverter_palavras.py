# Função que recebe uma frase e retorna uma nova frase com as letras de cada palavra invertidas.

def inverter_palavras(frase):
    palavras = frase.split()
    invertidas = [p[::-1] for p in palavras]
    return " ".join(invertidas)

# Teste
texto = input("Digite uma frase: ")
resultado = inverter_palavras(texto)
print("Frase com palavras invertidas:", resultado)
