# Programa que lê a idade de uma pessoa em dias e mostra em anos, meses e dias.

dias = int(input("Digite sua idade em dias: "))

anos = dias // 365
meses = (dias % 365) // 30
dias_restantes = (dias % 365) % 30

print(f"{anos} ano(s), {meses} mes(es) e {dias_restantes} dia(s).")
