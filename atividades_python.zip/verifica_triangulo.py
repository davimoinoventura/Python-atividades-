# Programa que lê três valores a, b e c e verifica se formam um triângulo.
# Se sim, calcula a área do triângulo (usando fórmula de Heron).

import math

a = int(input("Digite o valor de a: "))
b = int(input("Digite o valor de b: "))
c = int(input("Digite o valor de c: "))

# Verifica se formam triângulo
if a < b + c and b < a + c and c < a + b:
    p = (a + b + c) / 2
    area = math.sqrt(p * (p - a) * (p - b) * (p - c))
    print("Os valores formam um triângulo.")
    print(f"A área do triângulo é: {area:.2f}")
else:
    print("Os valores NÃO formam um triângulo.")
    print(f"Valores lidos: a={a}, b={b}, c={c}")
